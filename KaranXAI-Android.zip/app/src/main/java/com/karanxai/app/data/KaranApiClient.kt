package com.karanxai.app.data

import com.karanxai.app.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.isActive
import kotlinx.coroutines.withContext
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.BufferedReader
import java.io.InputStreamReader
import java.util.concurrent.TimeUnit

@Serializable
private data class ApiChatImage(
    val mimeType: String,
    val data: String
)

@Serializable
private data class ApiChatMessage(
    val role: String,
    val text: String,
    val image: ApiChatImage? = null
)

@Serializable
private data class ApiChatRequest(
    val messages: List<ApiChatMessage>,
    val language: String,
    val classLevel: String,
    val subject: String
)

@Serializable
private data class ApiNotesRequest(
    val classLevel: String,
    val subject: String,
    val topic: String,
    val depth: String,
    val language: String
)

@Serializable
private data class ApiQuizRequest(
    val classLevel: String,
    val subject: String,
    val topic: String,
    val count: Int,
    val difficulty: String,
    val language: String
)

@Serializable
private data class SseChunk(
    val text: String? = null,
    val done: Boolean? = null,
    val error: String? = null
)

@Serializable
private data class ApiErrorResponse(
    val error: String? = null
)

class KaranApiClient {
    private val json = Json {
        ignoreUnknownKeys = true
        encodeDefaults = false
    }

    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(120, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()

    private val jsonMediaType = "application/json; charset=utf-8".toMediaType()
    private val baseUrl = BuildConfig.API_BASE_URL.trimEnd('/')

    fun streamChat(
        messages: List<ChatMessage>,
        language: Language,
        classLevel: ClassLevel,
        subject: ChatSubject
    ): Flow<String> = streamSse(
        endpoint = "$baseUrl/api/chat/stream",
        bodyJson = json.encodeToString(
            ApiChatRequest(
                messages = messages.map { m ->
                    ApiChatMessage(
                        role = m.role,
                        text = m.text,
                        image = m.image?.let { ApiChatImage(it.mimeType, it.base64Data) }
                    )
                },
                language = language.apiCode,
                classLevel = classLevel.apiCode,
                subject = subject.apiCode
            )
        )
    )

    fun streamNotes(
        classLevel: ClassLevel,
        subject: StudySubject,
        topic: String,
        depth: NotesDepth,
        language: Language
    ): Flow<String> = streamSse(
        endpoint = "$baseUrl/api/notes/generate",
        bodyJson = json.encodeToString(
            ApiNotesRequest(
                classLevel = classLevel.apiCode,
                subject = subject.apiCode,
                topic = topic,
                depth = depth.apiCode,
                language = language.apiCode
            )
        )
    )

    suspend fun generateQuiz(
        classLevel: ClassLevel,
        subject: StudySubject,
        topic: String,
        count: Int,
        difficulty: QuizDifficulty,
        language: Language
    ): QuizData = withContext(Dispatchers.IO) {
        val body = json.encodeToString(
            ApiQuizRequest(
                classLevel = classLevel.apiCode,
                subject = subject.apiCode,
                topic = topic,
                count = count,
                difficulty = difficulty.apiCode,
                language = language.apiCode
            )
        ).toRequestBody(jsonMediaType)

        val request = Request.Builder()
            .url("$baseUrl/api/quiz/generate")
            .post(body)
            .build()

        client.newCall(request).execute().use { response ->
            val raw = response.body?.string().orEmpty()
            if (!response.isSuccessful) {
                val err = runCatching { json.decodeFromString<ApiErrorResponse>(raw).error }.getOrNull()
                throw IllegalStateException(err ?: "Server returned HTTP ${response.code}")
            }
            json.decodeFromString<QuizData>(raw)
        }
    }

    private fun streamSse(endpoint: String, bodyJson: String): Flow<String> = flow {
        val request = Request.Builder()
            .url(endpoint)
            .post(bodyJson.toRequestBody(jsonMediaType))
            .header("Accept", "text/event-stream")
            .build()

        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) {
                val rawErr = response.body?.string().orEmpty()
                val parsedErr = runCatching {
                    json.decodeFromString<ApiErrorResponse>(rawErr).error
                }.getOrNull()
                throw IllegalStateException(parsedErr ?: "Server returned HTTP ${response.code}")
            }

            val stream = response.body?.byteStream()
                ?: throw IllegalStateException("Empty response stream from server.")

            BufferedReader(InputStreamReader(stream, Charsets.UTF_8)).use { reader ->
                while (currentCoroutineContext().isActive) {
                    val line = reader.readLine() ?: break
                    val trimmed = line.trim()
                    if (!trimmed.startsWith("data:")) continue
                    val payload = trimmed.removePrefix("data:").trim()
                    if (payload.isEmpty()) continue

                    val chunk = runCatching { json.decodeFromString<SseChunk>(payload) }.getOrNull()
                        ?: continue
                    if (chunk.error != null) {
                        throw IllegalStateException(chunk.error)
                    }
                    if (!chunk.text.isNullOrEmpty()) {
                        emit(chunk.text)
                    }
                    if (chunk.done == true) {
                        break
                    }
                }
            }
        }
    }.flowOn(Dispatchers.IO)
}
