package com.karanxai.app.data

import kotlinx.serialization.Serializable

@Serializable
enum class Language(val apiCode: String) {
    EN("en"),
    HI("hi")
}

@Serializable
enum class ClassLevel(val apiCode: String) {
    CLASS_10("10"),
    CLASS_11("11"),
    CLASS_12("12"),
    GENERAL("general")
}

@Serializable
enum class StudySubject(val apiCode: String) {
    PHYSICS("physics"),
    CHEMISTRY("chemistry"),
    MATHEMATICS("mathematics")
}

@Serializable
enum class ChatSubject(val apiCode: String) {
    GENERAL("general"),
    PHYSICS("physics"),
    CHEMISTRY("chemistry"),
    MATHEMATICS("mathematics")
}

enum class ActiveTab {
    CHAT,
    CURRICULUM,
    NOTES,
    QUIZ
}

@Serializable
data class ImageAttachmentData(
    val mimeType: String,
    val base64Data: String,
    val fileName: String = "question.jpg"
)

@Serializable
data class ChatMessage(
    val id: String,
    val role: String, // "user" or "model"
    val text: String,
    val image: ImageAttachmentData? = null,
    val createdAt: Long = System.currentTimeMillis()
)

@Serializable
data class ChatSession(
    val id: String,
    val title: String = "",
    val classLevel: ClassLevel = ClassLevel.CLASS_12,
    val subject: ChatSubject = ChatSubject.GENERAL,
    val messages: List<ChatMessage> = emptyList(),
    val updatedAt: Long = System.currentTimeMillis()
)

@Serializable
enum class NotesDepth(val apiCode: String) {
    DETAILED("detailed"),
    QUICK("quick"),
    FORMULAS("formulas")
}

@Serializable
data class SavedNote(
    val id: String,
    val title: String,
    val classLevel: ClassLevel,
    val subject: StudySubject,
    val depth: NotesDepth,
    val language: Language,
    val content: String,
    val createdAt: Long = System.currentTimeMillis()
)

@Serializable
enum class QuizDifficulty(val apiCode: String) {
    EASY("easy"),
    BOARD("board"),
    COMPETITIVE("competitive")
}

@Serializable
data class QuizQuestion(
    val id: Int,
    val question: String,
    val options: List<String>,
    val correctIndex: Int,
    val explanation: String,
    val conceptTag: String = ""
)

@Serializable
data class QuizData(
    val title: String,
    val questions: List<QuizQuestion>
)

@Serializable
data class QuizAttempt(
    val id: String,
    val title: String,
    val classLevel: ClassLevel,
    val subject: StudySubject,
    val score: Int,
    val total: Int,
    val language: Language,
    val createdAt: Long = System.currentTimeMillis()
)
