package com.karanxai.app.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.karanxai.app.data.ActiveTab
import com.karanxai.app.data.BilingualStrings
import com.karanxai.app.data.Language
import com.karanxai.app.ui.screens.ChatScreen
import com.karanxai.app.ui.screens.CurriculumScreen
import com.karanxai.app.ui.screens.NotesScreen
import com.karanxai.app.ui.screens.QuizScreen
import com.karanxai.app.ui.theme.Amber400
import com.karanxai.app.ui.theme.KaranXAITheme

@Composable
fun KaranXAIApp(
    viewModel: MainViewModel = viewModel()
) {
    val uiState by viewModel.uiState.collectAsState()
    val t = BilingualStrings.get(uiState.language)

    KaranXAITheme(darkTheme = uiState.isDarkTheme) {
        Scaffold(
            containerColor = MaterialTheme.colorScheme.background,
            topBar = {
                Column {
                    Surface(
                        color = MaterialTheme.colorScheme.surface,
                        border = BorderStroke(0.5.dp, MaterialTheme.colorScheme.outline)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .statusBarsPadding()
                                .height(56.dp)
                                .padding(horizontal = 16.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = buildAnnotatedString {
                                    append("Karan")
                                    withStyle(SpanStyle(color = MaterialTheme.colorScheme.primary)) {
                                        append(".xAI")
                                    }
                                },
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.Bold
                            )

                            Button(
                                onClick = { viewModel.createNewSession() },
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier.heightIn(min = 40.dp),
                                contentPadding = PaddingValues(horizontal = 14.dp)
                            ) {
                                Text(
                                    text = "+ ${t.newChat}",
                                    style = MaterialTheme.typography.labelMedium,
                                    maxLines = 1
                                )
                            }
                        }
                    }

                    // Slim Workspace Utility Strip (Language & Theme)
                    Surface(
                        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                        border = BorderStroke(0.5.dp, MaterialTheme.colorScheme.outline)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 16.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = t.topSubtitle,
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.weight(1f)
                            )

                            Row(
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Surface(
                                    onClick = { viewModel.toggleLanguage() },
                                    shape = RoundedCornerShape(8.dp),
                                    color = MaterialTheme.colorScheme.surface,
                                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(5.dp)
                                    ) {
                                        Icon(
                                            Icons.Outlined.Translate,
                                            contentDescription = null,
                                            tint = MaterialTheme.colorScheme.primary,
                                            modifier = Modifier.size(14.dp)
                                        )
                                        Text(
                                            text = if (uiState.language == Language.EN) "English / हिंदी" else "हिंदी / English",
                                            style = MaterialTheme.typography.labelSmall,
                                            maxLines = 1
                                        )
                                    }
                                }

                                Surface(
                                    onClick = { viewModel.toggleTheme() },
                                    shape = RoundedCornerShape(8.dp),
                                    color = MaterialTheme.colorScheme.surface,
                                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                                ) {
                                    Box(modifier = Modifier.padding(6.dp)) {
                                        Icon(
                                            imageVector = if (uiState.isDarkTheme) Icons.Outlined.LightMode else Icons.Outlined.DarkMode,
                                            contentDescription = null,
                                            tint = if (uiState.isDarkTheme) Amber400 else MaterialTheme.colorScheme.onSurfaceVariant,
                                            modifier = Modifier.size(16.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            },
            bottomBar = {
                NavigationBar(
                    containerColor = MaterialTheme.colorScheme.surface,
                    tonalElevation = 0.dp
                ) {
                    val items = listOf(
                        Triple(ActiveTab.CHAT, t.navChat, Icons.Outlined.Forum),
                        Triple(ActiveTab.CURRICULUM, t.navCurriculum, Icons.Outlined.MenuBook),
                        Triple(ActiveTab.NOTES, t.navNotes, Icons.Outlined.Description),
                        Triple(ActiveTab.QUIZ, t.navQuiz, Icons.Outlined.CheckCircle)
                    )
                    items.forEach { (tab, label, icon) ->
                        val selected = uiState.activeTab == tab
                        NavigationBarItem(
                            selected = selected,
                            onClick = { viewModel.selectTab(tab) },
                            icon = { Icon(icon, contentDescription = label) },
                            label = { Text(label, maxLines = 1) }
                        )
                    }
                }
            }
        ) { innerPadding ->
            val contentModifier = Modifier.padding(innerPadding)
            when (uiState.activeTab) {
                ActiveTab.CHAT -> ChatScreen(
                    uiState = uiState,
                    onSelectSession = viewModel::selectSession,
                    onNewSession = { viewModel.createNewSession() },
                    onDeleteSession = viewModel::deleteSession,
                    onUpdateClass = viewModel::updateActiveSessionClass,
                    onUpdateSubject = viewModel::updateActiveSessionSubject,
                    onSendMessage = viewModel::sendChatMessage,
                    onStopStreaming = viewModel::stopChatStreaming,
                    onClearError = viewModel::clearChatError,
                    modifier = contentModifier
                )
                ActiveTab.CURRICULUM -> CurriculumScreen(
                    language = uiState.language,
                    onAskTutor = viewModel::askTutorFromHub,
                    onGenerateNotes = viewModel::generateNotesFromHub,
                    onStartQuiz = viewModel::startQuizFromHub,
                    modifier = contentModifier
                )
                ActiveTab.NOTES -> NotesScreen(
                    uiState = uiState,
                    onSelectClass = viewModel::setNotesClass,
                    onSelectSubject = viewModel::setNotesSubject,
                    onTopicChange = viewModel::setNotesTopic,
                    onSelectDepth = viewModel::setNotesDepth,
                    onGenerateNotes = viewModel::generateNotes,
                    onSaveNote = viewModel::saveCurrentNote,
                    onOpenNote = viewModel::openSavedNote,
                    onDeleteNote = viewModel::deleteSavedNote,
                    modifier = contentModifier
                )
                ActiveTab.QUIZ -> QuizScreen(
                    uiState = uiState,
                    onSelectClass = viewModel::setQuizClass,
                    onSelectSubject = viewModel::setQuizSubject,
                    onTopicChange = viewModel::setQuizTopic,
                    onSelectCount = viewModel::setQuizCount,
                    onSelectDifficulty = viewModel::setQuizDifficulty,
                    onGenerateQuiz = viewModel::generateQuiz,
                    onSelectAnswer = viewModel::selectQuizAnswer,
                    onSetQuestionIndex = viewModel::setQuizQuestionIndex,
                    onSubmitQuiz = viewModel::submitQuiz,
                    onRetakeQuiz = viewModel::retakeQuiz,
                    onNewQuiz = viewModel::resetQuizSetup,
                    onExplainInChat = viewModel::explainQuizQuestionInChat,
                    modifier = contentModifier
                )
            }
        }
    }
}
