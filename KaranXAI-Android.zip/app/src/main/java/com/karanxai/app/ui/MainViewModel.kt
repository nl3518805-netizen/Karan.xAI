package com.karanxai.app.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.karanxai.app.data.*
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.onCompletion
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.util.UUID

data class MainUiState(
    val language: Language = Language.EN,
    val isDarkTheme: Boolean = false,
    val activeTab: ActiveTab = ActiveTab.CHAT,
    val sessions: List<ChatSession> = emptyList(),
    val activeSessionId: String = "",
    val isChatStreaming: Boolean = false,
    val chatError: String? = null,
    val savedNotes: List<SavedNote> = emptyList(),
    val notesClass: ClassLevel = ClassLevel.CLASS_12,
    val notesSubject: StudySubject = StudySubject.PHYSICS,
    val notesTopic: String = "",
    val notesDepth: NotesDepth = NotesDepth.DETAILED,
    val notesActiveTitle: String = "",
    val notesContent: String = "",
    val isNotesGenerating: Boolean = false,
    val notesError: String? = null,
    val quizClass: ClassLevel = ClassLevel.CLASS_12,
    val quizSubject: StudySubject = StudySubject.PHYSICS,
    val quizTopic: String = "",
    val quizCount: Int = 5,
    val quizDifficulty: QuizDifficulty = QuizDifficulty.BOARD,
    val isQuizLoading: Boolean = false,
    val quizError: String? = null,
    val activeQuiz: QuizData? = null,
    val quizCurrentIndex: Int = 0,
    val quizAnswers: Map<Int, Int> = emptyMap(),
    val quizSubmitted: Boolean = false,
    val quizHistory: List<QuizAttempt> = emptyList()
)

class MainViewModel(application: Application) : AndroidViewModel(application) {
    private val store = LocalStudyStore(application.applicationContext)
    private val api = KaranApiClient()

    private val _uiState = MutableStateFlow(MainUiState())
    val uiState: StateFlow<MainUiState> = _uiState.asStateFlow()

    private var chatJob: Job? = null
    private var notesJob: Job? = null

    init {
        val loadedSessions = store.loadSessions().ifEmpty {
            listOf(createDefaultSession())
        }
        _uiState.value = MainUiState(
            language = store.loadLanguage(),
            isDarkTheme = store.loadDarkTheme(),
            sessions = loadedSessions,
            activeSessionId = loadedSessions.first().id,
            savedNotes = store.loadNotes(),
            quizHistory = store.loadQuizHistory()
        )
    }

    private fun createDefaultSession(
        classLevel: ClassLevel = ClassLevel.CLASS_12,
        subject: ChatSubject = ChatSubject.GENERAL
    ): ChatSession = ChatSession(
        id = "sess-${UUID.randomUUID().toString().take(8)}",
        classLevel = classLevel,
        subject = subject
    )

    fun toggleLanguage() {
        _uiState.update { state ->
            val next = if (state.language == Language.EN) Language.HI else Language.EN
            store.saveLanguage(next)
            state.copy(language = next)
        }
    }

    fun toggleTheme() {
        _uiState.update { state ->
            val next = !state.isDarkTheme
            store.saveDarkTheme(next)
            state.copy(isDarkTheme = next)
        }
    }

    fun selectTab(tab: ActiveTab) {
        _uiState.update { it.copy(activeTab = tab) }
    }

    fun selectSession(sessionId: String) {
        _uiState.update { it.copy(activeSessionId = sessionId, chatError = null) }
    }

    fun createNewSession(
        classLevel: ClassLevel = ClassLevel.CLASS_12,
        subject: ChatSubject = ChatSubject.GENERAL,
        initialPrompt: String? = null
    ) {
        val next = createDefaultSession(classLevel, subject)
        _uiState.update { state ->
            val updated = listOf(next) + state.sessions
            store.saveSessions(updated)
            state.copy(
                sessions = updated,
                activeSessionId = next.id,
                activeTab = ActiveTab.CHAT,
                chatError = null
            )
        }
        if (!initialPrompt.isNullOrBlank()) {
            sendChatMessage(initialPrompt)
        }
    }

    fun deleteSession(sessionId: String) {
        _uiState.update { state ->
            val remaining = state.sessions.filterNot { it.id == sessionId }
            val nextSessions = remaining.ifEmpty { listOf(createDefaultSession()) }
            val nextActive = if (state.activeSessionId == sessionId) {
                nextSessions.first().id
            } else {
                state.activeSessionId
            }
            store.saveSessions(nextSessions)
            state.copy(sessions = nextSessions, activeSessionId = nextActive)
        }
    }

    fun updateActiveSessionClass(level: ClassLevel) {
        updateActiveSession { it.copy(classLevel = level) }
    }

    fun updateActiveSessionSubject(subject: ChatSubject) {
        updateActiveSession { it.copy(subject = subject) }
    }

    private fun updateActiveSession(transform: (ChatSession) -> ChatSession) {
        _uiState.update { state ->
            val updated = state.sessions.map { s ->
                if (s.id == state.activeSessionId) transform(s) else s
            }
            store.saveSessions(updated)
            state.copy(sessions = updated)
        }
    }

    fun stopChatStreaming() {
        chatJob?.cancel()
        chatJob = null
        _uiState.update { it.copy(isChatStreaming = false) }
    }

    fun clearChatError() {
        _uiState.update { it.copy(chatError = null) }
    }

    fun sendChatMessage(
        rawText: String,
        attachment: ImageAttachmentData? = null,
        regenerateFromIndex: Int? = null
    ) {
        val state = _uiState.value
        if (state.isChatStreaming) return
        val session = state.sessions.firstOrNull { it.id == state.activeSessionId } ?: return

        val trimmed = rawText.trim()
        if (trimmed.isEmpty() && attachment == null && regenerateFromIndex == null) return

        val historyMessages = if (regenerateFromIndex != null) {
            session.messages.take(regenerateFromIndex)
        } else {
            val defaultImgText = if (state.language == Language.HI) {
                "कृपया इस प्रश्न को हल करें।"
            } else {
                "Please solve this question."
            }
            val userMsg = ChatMessage(
                id = "msg-${System.currentTimeMillis()}-u",
                role = "user",
                text = trimmed.ifEmpty { defaultImgText },
                image = attachment
            )
            session.messages + userMsg
        }

        val assistantId = "msg-${System.currentTimeMillis()}-m"
        val placeholder = ChatMessage(
            id = assistantId,
            role = "model",
            text = ""
        )

        val nextTitle = if (session.title.isBlank() && historyMessages.isNotEmpty()) {
            val firstText = historyMessages.first().text
            if (firstText.length > 40) firstText.take(40) + "…" else firstText
        } else {
            session.title
        }

        updateActiveSession {
            it.copy(
                title = nextTitle,
                messages = historyMessages + placeholder,
                updatedAt = System.currentTimeMillis()
            )
        }

        _uiState.update { it.copy(isChatStreaming = true, chatError = null) }

        val buffer = StringBuilder()
        chatJob = viewModelScope.launch {
            api.streamChat(
                messages = historyMessages,
                language = state.language,
                classLevel = session.classLevel,
                subject = session.subject
            ).catch { err ->
                _uiState.update { s ->
                    val cleanedSessions = s.sessions.map { sess ->
                        if (sess.id == s.activeSessionId) {
                            sess.copy(
                                messages = sess.messages.filterNot {
                                    it.id == assistantId && it.text.isBlank()
                                }
                            )
                        } else sess
                    }
                    store.saveSessions(cleanedSessions)
                    s.copy(
                        sessions = cleanedSessions,
                        isChatStreaming = false,
                        chatError = err.message ?: "Failed to connect to Karan.xAI server."
                    )
                }
            }.onCompletion {
                _uiState.update { it.copy(isChatStreaming = false) }
            }.collect { delta ->
                buffer.append(delta)
                val fullText = buffer.toString()
                updateActiveSession { sess ->
                    sess.copy(
                        messages = sess.messages.map { m ->
                            if (m.id == assistantId) m.copy(text = fullText) else m
                        },
                        updatedAt = System.currentTimeMillis()
                    )
                }
            }
        }
    }

    // Curriculum Hub Actions
    fun askTutorFromHub(level: ClassLevel, subject: StudySubject, topic: String) {
        val lang = _uiState.value.language
        val subjLabel = BilingualStrings.get(lang).subjectLabel(subject)
        val prompt = if (lang == Language.HI) {
            "कक्षा ${level.apiCode} ($subjLabel) के अध्याय \"$topic\" के मुख्य सिद्धांत, सूत्र और एक उदाहरण सरल भाषा में समझाएं।"
        } else {
            "Explain the core concepts, key formulas, and one solved example for Class ${level.apiCode} $subjLabel chapter: \"$topic\"."
        }
        val chatSubj = when (subject) {
            StudySubject.PHYSICS -> ChatSubject.PHYSICS
            StudySubject.CHEMISTRY -> ChatSubject.CHEMISTRY
            StudySubject.MATHEMATICS -> ChatSubject.MATHEMATICS
        }
        createNewSession(classLevel = level, subject = chatSubj, initialPrompt = prompt)
    }

    fun generateNotesFromHub(level: ClassLevel, subject: StudySubject, topic: String) {
        _uiState.update {
            it.copy(
                activeTab = ActiveTab.NOTES,
                notesClass = level,
                notesSubject = subject,
                notesTopic = topic
            )
        }
        generateNotes()
    }

    fun startQuizFromHub(level: ClassLevel, subject: StudySubject, topic: String) {
        _uiState.update {
            it.copy(
                activeTab = ActiveTab.QUIZ,
                quizClass = level,
                quizSubject = subject,
                quizTopic = topic
            )
        }
        generateQuiz()
    }

    // Notes Workspace
    fun setNotesClass(level: ClassLevel) = _uiState.update { it.copy(notesClass = level) }
    fun setNotesSubject(subject: StudySubject) = _uiState.update { it.copy(notesSubject = subject) }
    fun setNotesTopic(topic: String) = _uiState.update { it.copy(notesTopic = topic) }
    fun setNotesDepth(depth: NotesDepth) = _uiState.update { it.copy(notesDepth = depth) }

    fun generateNotes() {
        val state = _uiState.value
        val topic = state.notesTopic.trim()
        if (topic.isEmpty() || state.isNotesGenerating) return

        notesJob?.cancel()
        _uiState.update {
            it.copy(
                isNotesGenerating = true,
                notesError = null,
                notesContent = "",
                notesActiveTitle = topic
            )
        }

        val buffer = StringBuilder()
        notesJob = viewModelScope.launch {
            api.streamNotes(
                classLevel = state.notesClass,
                subject = state.notesSubject,
                topic = topic,
                depth = state.notesDepth,
                language = state.language
            ).catch { err ->
                _uiState.update {
                    it.copy(
                        isNotesGenerating = false,
                        notesError = err.message ?: "Failed to generate notes."
                    )
                }
            }.onCompletion {
                _uiState.update { it.copy(isNotesGenerating = false) }
            }.collect { delta ->
                buffer.append(delta)
                val text = buffer.toString()
                _uiState.update { it.copy(notesContent = text) }
            }
        }
    }

    fun saveCurrentNote() {
        val state = _uiState.value
        if (state.notesContent.isBlank()) return
        val note = SavedNote(
            id = "note-${System.currentTimeMillis()}",
            title = state.notesActiveTitle.ifBlank { state.notesTopic },
            classLevel = state.notesClass,
            subject = state.notesSubject,
            depth = state.notesDepth,
            language = state.language,
            content = state.notesContent
        )
        _uiState.update { s ->
            val updated = listOf(note) + s.savedNotes
            store.saveNotes(updated)
            s.copy(savedNotes = updated)
        }
    }

    fun openSavedNote(note: SavedNote) {
        _uiState.update {
            it.copy(
                notesClass = note.classLevel,
                notesSubject = note.subject,
                notesTopic = note.title,
                notesActiveTitle = note.title,
                notesDepth = note.depth,
                notesContent = note.content,
                notesError = null
            )
        }
    }

    fun deleteSavedNote(id: String) {
        _uiState.update { s ->
            val updated = s.savedNotes.filterNot { it.id == id }
            store.saveNotes(updated)
            s.copy(savedNotes = updated)
        }
    }

    // Quiz Workspace
    fun setQuizClass(level: ClassLevel) = _uiState.update { it.copy(quizClass = level) }
    fun setQuizSubject(subject: StudySubject) = _uiState.update { it.copy(quizSubject = subject) }
    fun setQuizTopic(topic: String) = _uiState.update { it.copy(quizTopic = topic) }
    fun setQuizCount(count: Int) = _uiState.update { it.copy(quizCount = count) }
    fun setQuizDifficulty(diff: QuizDifficulty) = _uiState.update { it.copy(quizDifficulty = diff) }

    fun generateQuiz() {
        val state = _uiState.value
        val topic = state.quizTopic.trim()
        if (topic.isEmpty() || state.isQuizLoading) return

        _uiState.update {
            it.copy(
                isQuizLoading = true,
                quizError = null,
                activeQuiz = null,
                quizAnswers = emptyMap(),
                quizCurrentIndex = 0,
                quizSubmitted = false
            )
        }

        viewModelScope.launch {
            try {
                val data = api.generateQuiz(
                    classLevel = state.quizClass,
                    subject = state.quizSubject,
                    topic = topic,
                    count = state.quizCount,
                    difficulty = state.quizDifficulty,
                    language = state.language
                )
                if (data.questions.isEmpty()) {
                    throw IllegalStateException("No questions returned for this topic.")
                }
                _uiState.update { it.copy(activeQuiz = data, isQuizLoading = false) }
            } catch (err: Exception) {
                _uiState.update {
                    it.copy(
                        isQuizLoading = false,
                        quizError = err.message ?: "Failed to prepare quiz."
                    )
                }
            }
        }
    }

    fun selectQuizAnswer(questionId: Int, optionIndex: Int) {
        if (_uiState.value.quizSubmitted) return
        _uiState.update { s ->
            s.copy(quizAnswers = s.quizAnswers + (questionId to optionIndex))
        }
    }

    fun setQuizQuestionIndex(index: Int) {
        val maxIdx = (_uiState.value.activeQuiz?.questions?.size ?: 1) - 1
        _uiState.update { it.copy(quizCurrentIndex = index.coerceIn(0, maxIdx)) }
    }

    fun submitQuiz() {
        val state = _uiState.value
        val quiz = state.activeQuiz ?: return
        val score = quiz.questions.count { q -> state.quizAnswers[q.id] == q.correctIndex }
        val attempt = QuizAttempt(
            id = "quiz-${System.currentTimeMillis()}",
            title = quiz.title,
            classLevel = state.quizClass,
            subject = state.quizSubject,
            score = score,
            total = quiz.questions.size,
            language = state.language
        )
        _uiState.update { s ->
            val updated = (listOf(attempt) + s.quizHistory).take(20)
            store.saveQuizHistory(updated)
            s.copy(quizSubmitted = true, quizHistory = updated)
        }
    }

    fun retakeQuiz() {
        _uiState.update {
            it.copy(quizAnswers = emptyMap(), quizCurrentIndex = 0, quizSubmitted = false)
        }
    }

    fun resetQuizSetup() {
        _uiState.update {
            it.copy(activeQuiz = null, quizAnswers = emptyMap(), quizCurrentIndex = 0, quizSubmitted = false)
        }
    }

    fun explainQuizQuestionInChat(question: QuizQuestion) {
        val state = _uiState.value
        val suffix = if (state.language == Language.HI) {
            "कृपया इस MCQ प्रश्न का हल विस्तार से समझाएं।"
        } else {
            "Please explain this MCQ question and solution step-by-step."
        }
        val chatSubj = when (state.quizSubject) {
            StudySubject.PHYSICS -> ChatSubject.PHYSICS
            StudySubject.CHEMISTRY -> ChatSubject.CHEMISTRY
            StudySubject.MATHEMATICS -> ChatSubject.MATHEMATICS
        }
        createNewSession(
            classLevel = state.quizClass,
            subject = chatSubj,
            initialPrompt = "${question.question}\n\n$suffix"
        )
    }
}
