package com.karanxai.app.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.KeyboardArrowLeft
import androidx.compose.material.icons.automirrored.outlined.KeyboardArrowRight
import androidx.compose.material.icons.outlined.Cancel
import androidx.compose.material.icons.outlined.CheckCircle
import androidx.compose.material.icons.outlined.Forum
import androidx.compose.material.icons.outlined.Refresh
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.karanxai.app.data.*
import com.karanxai.app.ui.MainUiState
import com.karanxai.app.ui.components.MarkdownText
import com.karanxai.app.ui.theme.Emerald50
import com.karanxai.app.ui.theme.Emerald600
import com.karanxai.app.ui.theme.Red50
import com.karanxai.app.ui.theme.Red600

@Composable
fun QuizScreen(
    uiState: MainUiState,
    onSelectClass: (ClassLevel) -> Unit,
    onSelectSubject: (StudySubject) -> Unit,
    onTopicChange: (String) -> Unit,
    onSelectCount: (Int) -> Unit,
    onSelectDifficulty: (QuizDifficulty) -> Unit,
    onGenerateQuiz: () -> Unit,
    onSelectAnswer: (Int, Int) -> Unit,
    onSetQuestionIndex: (Int) -> Unit,
    onSubmitQuiz: () -> Unit,
    onRetakeQuiz: () -> Unit,
    onNewQuiz: () -> Unit,
    onExplainInChat: (QuizQuestion) -> Unit,
    modifier: Modifier = Modifier
) {
    val t = BilingualStrings.get(uiState.language)
    val activeQuiz = uiState.activeQuiz

    if (activeQuiz != null) {
        val currentQ = activeQuiz.questions[uiState.quizCurrentIndex]
        val selectedOpt = uiState.quizAnswers[currentQ.id]
        val score = activeQuiz.questions.count { q -> uiState.quizAnswers[q.id] == q.correctIndex }
        val accuracy = if (activeQuiz.questions.isNotEmpty()) {
            (score * 100) / activeQuiz.questions.size
        } else 0

        LazyColumn(
            modifier = modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "${t.classLabel} ${uiState.quizClass.apiCode} · ${t.subjectLabel(uiState.quizSubject)}",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            text = activeQuiz.title,
                            style = MaterialTheme.typography.titleLarge,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                    OutlinedButton(
                        onClick = onNewQuiz,
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.heightIn(min = 40.dp)
                    ) {
                        Text(t.newQuiz, style = MaterialTheme.typography.labelMedium)
                    }
                }
            }

            if (uiState.quizSubmitted) {
                item {
                    Surface(
                        shape = RoundedCornerShape(16.dp),
                        color = MaterialTheme.colorScheme.surface,
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = t.scoreSummary,
                                    style = MaterialTheme.typography.labelMedium,
                                    color = MaterialTheme.colorScheme.primary
                                )
                                Row(
                                    verticalAlignment = Alignment.Bottom,
                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    Text(
                                        text = "$score/${activeQuiz.questions.size}",
                                        style = MaterialTheme.typography.headlineMedium,
                                        fontFamily = FontFamily.Monospace
                                    )
                                    Text(
                                        text = "${t.accuracy}: $accuracy%",
                                        style = MaterialTheme.typography.bodyMedium,
                                        fontFamily = FontFamily.Monospace,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                            OutlinedButton(
                                onClick = onRetakeQuiz,
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier.heightIn(min = 44.dp)
                            ) {
                                Icon(Icons.Outlined.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(Modifier.width(6.dp))
                                Text(t.retakeQuiz, style = MaterialTheme.typography.labelMedium)
                            }
                        }
                    }
                }
            }

            // Numbered Stepper
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    activeQuiz.questions.forEachIndexed { idx, q ->
                        val isCurr = idx == uiState.quizCurrentIndex
                        val userAns = uiState.quizAnswers[q.id]
                        val bg = when {
                            uiState.quizSubmitted && userAns == q.correctIndex -> Emerald50
                            uiState.quizSubmitted && userAns != q.correctIndex -> Red50
                            isCurr -> MaterialTheme.colorScheme.primary
                            userAns != null -> MaterialTheme.colorScheme.primaryContainer
                            else -> MaterialTheme.colorScheme.surface
                        }
                        val fg = when {
                            uiState.quizSubmitted && userAns == q.correctIndex -> Emerald600
                            uiState.quizSubmitted && userAns != q.correctIndex -> Red600
                            isCurr -> MaterialTheme.colorScheme.onPrimary
                            userAns != null -> MaterialTheme.colorScheme.onPrimaryContainer
                            else -> MaterialTheme.colorScheme.onSurface
                        }

                        Surface(
                            onClick = { onSetQuestionIndex(idx) },
                            modifier = Modifier.size(40.dp),
                            shape = RoundedCornerShape(10.dp),
                            color = bg,
                            border = BorderStroke(
                                if (isCurr) 2.dp else 1.dp,
                                if (isCurr) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline
                            )
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Text(
                                    text = "${idx + 1}",
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.SemiBold,
                                    color = fg
                                )
                            }
                        }
                    }
                }
            }

            // Active Question Card
            item {
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = MaterialTheme.colorScheme.surface,
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "${t.questionProgress} ${uiState.quizCurrentIndex + 1} / ${activeQuiz.questions.size}",
                                style = MaterialTheme.typography.labelMedium,
                                fontFamily = FontFamily.Monospace,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(
                                text = currentQ.conceptTag,
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }

                        MarkdownText(markdown = currentQ.question)

                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            currentQ.options.forEachIndexed { idx, opt ->
                                val isSelected = selectedOpt == idx
                                val isRight = idx == currentQ.correctIndex

                                val borderColor = when {
                                    uiState.quizSubmitted && isRight -> Emerald600
                                    uiState.quizSubmitted && isSelected && !isRight -> Red600
                                    isSelected -> MaterialTheme.colorScheme.primary
                                    else -> MaterialTheme.colorScheme.outline
                                }
                                val bgColor = when {
                                    uiState.quizSubmitted && isRight -> Emerald50
                                    uiState.quizSubmitted && isSelected && !isRight -> Red50
                                    isSelected -> MaterialTheme.colorScheme.primaryContainer
                                    else -> MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f)
                                }

                                Surface(
                                    onClick = { onSelectAnswer(currentQ.id, idx) },
                                    enabled = !uiState.quizSubmitted,
                                    shape = RoundedCornerShape(12.dp),
                                    color = bgColor,
                                    border = BorderStroke(1.dp, borderColor)
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .heightIn(min = 52.dp)
                                            .padding(horizontal = 12.dp, vertical = 10.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                                    ) {
                                        Surface(
                                            shape = RoundedCornerShape(6.dp),
                                            color = MaterialTheme.colorScheme.surface,
                                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                                            modifier = Modifier.size(26.dp)
                                        ) {
                                            Box(contentAlignment = Alignment.Center) {
                                                Text(
                                                    text = "${'A' + idx}",
                                                    fontFamily = FontFamily.Monospace,
                                                    fontWeight = FontWeight.SemiBold,
                                                    style = MaterialTheme.typography.labelMedium
                                                )
                                            }
                                        }
                                        Box(modifier = Modifier.weight(1f)) {
                                            MarkdownText(markdown = opt)
                                        }
                                        if (uiState.quizSubmitted && isRight) {
                                            Icon(Icons.Outlined.CheckCircle, contentDescription = t.correct, tint = Emerald600)
                                        } else if (uiState.quizSubmitted && isSelected && !isRight) {
                                            Icon(Icons.Outlined.Cancel, contentDescription = t.incorrect, tint = Red600)
                                        }
                                    }
                                }
                            }
                        }

                        if (uiState.quizSubmitted) {
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f),
                                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                            ) {
                                Column(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(12.dp),
                                    verticalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = t.explanation,
                                            style = MaterialTheme.typography.labelMedium,
                                            fontWeight = FontWeight.SemiBold
                                        )
                                        TextButton(onClick = { onExplainInChat(currentQ) }) {
                                            Icon(Icons.Outlined.Forum, contentDescription = null, modifier = Modifier.size(15.dp))
                                            Spacer(Modifier.width(4.dp))
                                            Text(t.explainInChat, style = MaterialTheme.typography.labelSmall)
                                        }
                                    }
                                    MarkdownText(markdown = currentQ.explanation)
                                }
                            }
                        }

                        HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.6f))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            OutlinedButton(
                                onClick = { onSetQuestionIndex(uiState.quizCurrentIndex - 1) },
                                enabled = uiState.quizCurrentIndex > 0,
                                modifier = Modifier.heightIn(min = 44.dp),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Icon(Icons.AutoMirrored.Outlined.KeyboardArrowLeft, contentDescription = null)
                                Text(t.prevQuestion)
                            }

                            if (uiState.quizCurrentIndex < activeQuiz.questions.lastIndex) {
                                Button(
                                    onClick = { onSetQuestionIndex(uiState.quizCurrentIndex + 1) },
                                    modifier = Modifier.heightIn(min = 44.dp),
                                    shape = RoundedCornerShape(10.dp)
                                ) {
                                    Text(t.nextQuestion)
                                    Icon(Icons.AutoMirrored.Outlined.KeyboardArrowRight, contentDescription = null)
                                }
                            } else if (!uiState.quizSubmitted) {
                                Button(
                                    onClick = onSubmitQuiz,
                                    enabled = uiState.quizAnswers.isNotEmpty(),
                                    colors = ButtonDefaults.buttonColors(containerColor = Emerald600),
                                    modifier = Modifier.heightIn(min = 44.dp),
                                    shape = RoundedCornerShape(10.dp)
                                ) {
                                    Icon(Icons.Outlined.CheckCircle, contentDescription = null, modifier = Modifier.size(18.dp))
                                    Spacer(Modifier.width(6.dp))
                                    Text(t.finishQuiz)
                                }
                            }
                        }
                    }
                }
            }
        }
        return
    }

    // Quiz Setup View
    val suggestedChapters = CurriculumData.chaptersFor(uiState.quizClass, uiState.quizSubject)

    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(
                    text = "Karan.xAI · ${t.quizTitle}",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.primary
                )
                Text(
                    text = t.quizTitle,
                    style = MaterialTheme.typography.headlineMedium,
                    color = MaterialTheme.colorScheme.onBackground
                )
                Text(
                    text = t.quizSubtitle,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        if (uiState.quizError != null) {
            item {
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = MaterialTheme.colorScheme.errorContainer
                ) {
                    Text(
                        text = uiState.quizError,
                        color = MaterialTheme.colorScheme.onErrorContainer,
                        style = MaterialTheme.typography.bodyMedium,
                        modifier = Modifier.padding(14.dp)
                    )
                }
            }
        }

        item {
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = MaterialTheme.colorScheme.surface,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf(
                            ClassLevel.CLASS_10,
                            ClassLevel.CLASS_11,
                            ClassLevel.CLASS_12
                        ).forEach { cls ->
                            FilterChip(
                                selected = uiState.quizClass == cls,
                                onClick = { onSelectClass(cls) },
                                label = { Text(t.classLabelText(cls), maxLines = 1) },
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        StudySubject.entries.forEach { subj ->
                            FilterChip(
                                selected = uiState.quizSubject == subj,
                                onClick = { onSelectSubject(subj) },
                                label = {
                                    Text(
                                        t.subjectLabel(subj),
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                },
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }

                    OutlinedTextField(
                        value = uiState.quizTopic,
                        onValueChange = onTopicChange,
                        placeholder = { Text(t.quizTopicPlaceholder) },
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    )

                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        suggestedChapters.forEach { ch ->
                            val name = if (uiState.language == Language.HI) ch.hi else ch.en
                            Text(
                                text = name,
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.primary,
                                modifier = Modifier
                                    .clickable { onTopicChange(name) }
                                    .padding(vertical = 3.dp)
                            )
                        }
                    }

                    Text(
                        text = t.questionCount,
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf(5, 10, 15).forEach { count ->
                            FilterChip(
                                selected = uiState.quizCount == count,
                                onClick = { onSelectCount(count) },
                                label = { Text("$count", fontFamily = FontFamily.Monospace) },
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }

                    Text(
                        text = t.difficulty,
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf(
                            QuizDifficulty.EASY to t.diffEasy,
                            QuizDifficulty.BOARD to t.diffBoard,
                            QuizDifficulty.COMPETITIVE to t.diffCompetitive
                        ).forEach { (diff, label) ->
                            FilterChip(
                                selected = uiState.quizDifficulty == diff,
                                onClick = { onSelectDifficulty(diff) },
                                label = { Text(label, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }

                    Button(
                        onClick = onGenerateQuiz,
                        enabled = uiState.quizTopic.isNotBlank() && !uiState.isQuizLoading,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        if (uiState.isQuizLoading) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(18.dp),
                                strokeWidth = 2.dp,
                                color = MaterialTheme.colorScheme.onPrimary
                            )
                            Spacer(Modifier.width(8.dp))
                            Text(t.generatingQuiz)
                        } else {
                            Icon(Icons.Outlined.CheckCircle, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(8.dp))
                            Text(t.generateQuiz)
                        }
                    }
                }
            }
        }

        if (uiState.quizHistory.isNotEmpty()) {
            item {
                Text(
                    text = t.recentQuizzes,
                    style = MaterialTheme.typography.titleMedium,
                    modifier = Modifier.padding(top = 4.dp)
                )
            }
            items(uiState.quizHistory.take(6), key = { it.id }) { attempt ->
                val pct = if (attempt.total > 0) (attempt.score * 100) / attempt.total else 0
                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = MaterialTheme.colorScheme.surface,
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 14.dp, vertical = 12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = attempt.title,
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.Medium,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = "${t.classLabel} ${attempt.classLevel.apiCode} · ${t.subjectLabel(attempt.subject)}",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text(
                                text = "${attempt.score}/${attempt.total}",
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "$pct%",
                                style = MaterialTheme.typography.labelSmall,
                                fontFamily = FontFamily.Monospace,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        }
    }
}
