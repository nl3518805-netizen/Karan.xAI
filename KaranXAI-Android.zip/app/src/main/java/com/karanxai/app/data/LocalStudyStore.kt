package com.karanxai.app.data

import android.content.Context
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

class LocalStudyStore(context: Context) {
    private val prefs = context.getSharedPreferences("karan_xai_prefs", Context.MODE_PRIVATE)
    private val json = Json {
        ignoreUnknownKeys = true
        encodeDefaults = true
    }

    fun loadLanguage(): Language {
        val code = prefs.getString("lang", Language.EN.name) ?: Language.EN.name
        return runCatching { Language.valueOf(code) }.getOrDefault(Language.EN)
    }

    fun saveLanguage(language: Language) {
        prefs.edit().putString("lang", language.name).apply()
    }

    fun loadDarkTheme(): Boolean = prefs.getBoolean("dark_theme", false)

    fun saveDarkTheme(dark: Boolean) {
        prefs.edit().putBoolean("dark_theme", dark).apply()
    }

    fun loadSessions(): List<ChatSession> {
        val raw = prefs.getString("sessions", null) ?: return emptyList()
        return runCatching { json.decodeFromString<List<ChatSession>>(raw) }.getOrDefault(emptyList())
    }

    fun saveSessions(sessions: List<ChatSession>) {
        prefs.edit().putString("sessions", json.encodeToString(sessions)).apply()
    }

    fun loadNotes(): List<SavedNote> {
        val raw = prefs.getString("notes", null) ?: return emptyList()
        return runCatching { json.decodeFromString<List<SavedNote>>(raw) }.getOrDefault(emptyList())
    }

    fun saveNotes(notes: List<SavedNote>) {
        prefs.edit().putString("notes", json.encodeToString(notes)).apply()
    }

    fun loadQuizHistory(): List<QuizAttempt> {
        val raw = prefs.getString("quiz_history", null) ?: return emptyList()
        return runCatching { json.decodeFromString<List<QuizAttempt>>(raw) }.getOrDefault(emptyList())
    }

    fun saveQuizHistory(history: List<QuizAttempt>) {
        prefs.edit().putString("quiz_history", json.encodeToString(history)).apply()
    }
}
