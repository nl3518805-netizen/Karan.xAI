package com.karanxai.app.ui.screens

import android.content.Intent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.karanxai.app.data.*
import com.karanxai.app.ui.MainUiState
import com.karanxai.app.ui.components.MarkdownText

@Composable
fun NotesScreen(
    uiState: MainUiState,
    onSelectClass: (ClassLevel) -> Unit,
    onSelectSubject: (StudySubject) -> Unit,
    onTopicChange: (String) -> Unit,
    onSelectDepth: (NotesDepth) -> Unit,
    onGenerateNotes: () -> Unit,
    onSaveNote: () -> Unit,
    onOpenNote: (SavedNote) -> Unit,
    onDeleteNote: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val t = BilingualStrings.get(uiState.language)
    val clipboard = LocalClipboardManager.current
    val context = LocalContext.current
    var copiedFeedback by remember(uiState.notesContent) { mutableStateOf(false) }
    var savedFeedback by remember(uiState.notesActiveTitle, uiState.isNotesGenerating) { mutableStateOf(false) }

    val suggestedChapters = CurriculumData.chaptersFor(uiState.notesClass, uiState.notesSubject)

    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(
                    text = "Karan.xAI · ${t.notesTitle}",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.primary
                )
                Text(
                    text = t.notesTitle,
                    style = MaterialTheme.typography.headlineMedium,
                    color = MaterialTheme.colorScheme.onBackground
                )
                Text(
                    text = t.notesSubtitle,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        // Generator Card
        item {
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = MaterialTheme.colorScheme.surface,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    // Class Selector
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf(
                            ClassLevel.CLASS_10,
                            ClassLevel.CLASS_11,
                            ClassLevel.CLASS_12
                        ).forEach { cls ->
                            val active = uiState.notesClass == cls
                            FilterChip(
                                selected = active,
                                onClick = { onSelectClass(cls) },
                                label = { Text(t.classLabelText(cls), maxLines = 1) },
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }

                    // Subject Selector
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        StudySubject.entries.forEach { subj ->
                            val active = uiState.notesSubject == subj
                            FilterChip(
                                selected = active,
                                onClick = { onSelectSubject(subj) },
                                label = {
                                    Text(
                                        t.subjectLabel(subj),
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                },
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }

                    OutlinedTextField(
                        value = uiState.notesTopic,
                        onValueChange = onTopicChange,
                        placeholder = { Text(t.topicPlaceholder) },
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    )

                    // Quick Chapter Links
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        suggestedChapters.take(3).forEach { ch ->
                            val name = if (uiState.language == Language.HI) ch.hi else ch.en
                            Text(
                                text = name,
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.primary,
                                modifier = Modifier
                                    .clickable { onTopicChange(name) }
                                    .padding(vertical = 3.dp)
                            )
                        }
                    }

                    // Format Selector
                    Text(
                        text = t.noteFormat,
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf(
                            NotesDepth.DETAILED to t.formatDetailed,
                            NotesDepth.QUICK to t.formatQuick,
                            NotesDepth.FORMULAS to t.formatFormulas
                        ).forEach { (depth, label) ->
                            val active = uiState.notesDepth == depth
                            Surface(
                                onClick = { onSelectDepth(depth) },
                                modifier = Modifier
                                    .weight(1f)
                                    .heightIn(min = 44.dp),
                                shape = RoundedCornerShape(10.dp),
                                color = if (active) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant,
                                border = BorderStroke(
                                    1.dp,
                                    if (active) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline
                                )
                            ) {
                                Box(contentAlignment = Alignment.Center, modifier = Modifier.padding(6.dp)) {
                                    Text(
                                        text = label,
                                        style = MaterialTheme.typography.labelSmall,
                                        color = if (active) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurface,
                                        maxLines = 2
                                    )
                                }
                            }
                        }
                    }

                    Button(
                        onClick = onGenerateNotes,
                        enabled = uiState.notesTopic.isNotBlank() && !uiState.isNotesGenerating,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        if (uiState.isNotesGenerating) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(18.dp),
                                strokeWidth = 2.dp,
                                color = MaterialTheme.colorScheme.onPrimary
                            )
                            Spacer(Modifier.width(8.dp))
                            Text(t.generatingNotes)
                        } else {
                            Icon(Icons.Outlined.Description, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(8.dp))
                            Text(t.generateNotes)
                        }
                    }
                }
            }
        }

        if (uiState.notesError != null) {
            item {
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = MaterialTheme.colorScheme.errorContainer
                ) {
                    Text(
                        text = uiState.notesError,
                        color = MaterialTheme.colorScheme.onErrorContainer,
                        style = MaterialTheme.typography.bodyMedium,
                        modifier = Modifier.padding(14.dp)
                    )
                }
            }
        }

        // Generated Notes Sheet
        if (uiState.notesContent.isNotBlank()) {
            item {
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = MaterialTheme.colorScheme.surface,
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "${t.classLabel} ${uiState.notesClass.apiCode} · ${t.subjectLabel(uiState.notesSubject)}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Text(
                                    text = uiState.notesActiveTitle,
                                    style = MaterialTheme.typography.titleMedium,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            }
                        }

                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(
                                onClick = {
                                    onSaveNote()
                                    savedFeedback = true
                                },
                                enabled = !uiState.isNotesGenerating,
                                modifier = Modifier.heightIn(min = 40.dp),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Icon(
                                    if (savedFeedback) Icons.Outlined.Check else Icons.Outlined.BookmarkAdd,
                                    contentDescription = null,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(Modifier.width(6.dp))
                                Text(if (savedFeedback) t.savedSuccess else t.saveNote, style = MaterialTheme.typography.labelMedium)
                            }

                            OutlinedButton(
                                onClick = {
                                    clipboard.setText(AnnotatedString(uiState.notesContent))
                                    copiedFeedback = true
                                },
                                modifier = Modifier.heightIn(min = 40.dp),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Icon(Icons.Outlined.ContentCopy, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(Modifier.width(6.dp))
                                Text(if (copiedFeedback) t.copied else t.copy, style = MaterialTheme.typography.labelMedium)
                            }

                            OutlinedButton(
                                onClick = {
                                    val shareIntent = Intent(Intent.ACTION_SEND).apply {
                                        type = "text/plain"
                                        putExtra(Intent.EXTRA_SUBJECT, uiState.notesActiveTitle)
                                        putExtra(Intent.EXTRA_TEXT, uiState.notesContent)
                                    }
                                    context.startActivity(Intent.createChooser(shareIntent, t.shareNotes))
                                },
                                modifier = Modifier.heightIn(min = 40.dp),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Icon(Icons.Outlined.Share, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(Modifier.width(6.dp))
                                Text(t.shareNotes, style = MaterialTheme.typography.labelMedium)
                            }
                        }

                        HorizontalDivider(color = MaterialTheme.colorScheme.outline)

                        MarkdownText(markdown = uiState.notesContent)
                    }
                }
            }
        }

        // Saved Notes Library
        item {
            Text(
                text = "${t.savedLibrary} (${uiState.savedNotes.size})",
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.onBackground,
                modifier = Modifier.padding(top = 4.dp)
            )
        }

        if (uiState.savedNotes.isEmpty()) {
            item {
                Text(
                    text = t.noSavedNotes,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        } else {
            items(uiState.savedNotes, key = { it.id }) { note ->
                Surface(
                    onClick = { onOpenNote(note) },
                    shape = RoundedCornerShape(14.dp),
                    color = MaterialTheme.colorScheme.surface,
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 14.dp, vertical = 12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = note.title,
                                style = MaterialTheme.typography.bodyLarge,
                                fontWeight = FontWeight.Medium,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = "${t.classLabel} ${note.classLevel.apiCode} · ${t.subjectLabel(note.subject)}",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        IconButton(onClick = { onDeleteNote(note.id) }) {
                            Icon(
                                Icons.Outlined.Delete,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        }
    }
}
