package com.karanxai.app.ui.theme

import androidx.compose.ui.graphics.Color

// Brand & Academic Indigo Accent (<=10% accent budget)
val Indigo600 = Color(0xFF4F46E5)
val Indigo700 = Color(0xFF4338CA)
val Indigo500 = Color(0xFF6366F1)
val Indigo400 = Color(0xFF818CF8)
val Indigo50 = Color(0xFFEEF2FF)
val Indigo950 = Color(0xFF1E1B4B)

// Neutral Light Surfaces (60% / 30%)
val Slate50 = Color(0xFFF8FAFC)
val Slate100 = Color(0xFFF1F5F9)
val Slate200 = Color(0xFFE2E8F0)
val Slate300 = Color(0xFFCBD5E1)
val Slate400 = Color(0xFF94A3B8)
val Slate500 = Color(0xFF64748B)
val Slate600 = Color(0xFF475569)
val Slate700 = Color(0xFF334155)
val Slate800 = Color(0xFF1E293B)
val Slate900 = Color(0xFF0F172A)
val Slate950 = Color(0xFF0B1120)

// Semantic Colors
val Emerald600 = Color(0xFF059669)
val Emerald50 = Color(0xFFECFDF5)
val Emerald950 = Color(0xFF022C22)

val Red600 = Color(0xFFDC2626)
val Red50 = Color(0xFFFEF2F2)
val Red950 = Color(0xFF450A0A)

val Amber400 = Color(0xFFFBBF24)
