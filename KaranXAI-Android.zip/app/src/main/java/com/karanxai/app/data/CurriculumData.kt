package com.karanxai.app.data

data class ChapterItem(
    val id: String,
    val en: String,
    val hi: String,
    val keyTopicsEn: String,
    val keyTopicsHi: String
)

object CurriculumData {
    private val class10 = mapOf(
        StudySubject.PHYSICS to listOf(
            ChapterItem("10-phy-1", "Light: Reflection & Refraction", "प्रकाश: परावर्तन तथा अपवर्तन", "Mirror formula, lens formula, Snell's law, power of lens", "दर्पण सूत्र, लेंस सूत्र, स्नेल का नियम, लेंस की क्षमता"),
            ChapterItem("10-phy-2", "The Human Eye & Colourful World", "मानव नेत्र तथा रंगबिरंगा संसार", "Myopia, hypermetropia, prism dispersion, atmospheric scattering", "निकट दृष्टि दोष, दूर दृष्टि दोष, प्रिज्म वर्ण-विक्षेपण"),
            ChapterItem("10-phy-3", "Electricity", "विद्युत", "Ohm's law, series & parallel resistors, Joule's heating law, power", "ओम का नियम, श्रेणी व समांतर क्रम, जूल का तापन नियम"),
            ChapterItem("10-phy-4", "Magnetic Effects of Electric Current", "विद्युत धारा के चुंबकीय प्रभाव", "Right-hand thumb rule, Fleming's left-hand rule, solenoid", "दक्षिण-हस्त अंगुष्ठ नियम, फ्लेमिंग का वामहस्त नियम")
        ),
        StudySubject.CHEMISTRY to listOf(
            ChapterItem("10-chem-1", "Chemical Reactions & Equations", "रासायनिक अभिक्रियाएं एवं समीकरण", "Balancing equations, redox, displacement, decomposition", "संतुलित समीकरण, उपचयन-अपचयन, विस्थापन अभिक्रिया"),
            ChapterItem("10-chem-2", "Acids, Bases & Salts", "अम्ल, क्षारक एवं लवण", "pH scale, neutralization, baking soda, Plaster of Paris", "pH स्केल, उदासीनीकरण, बेकिंग सोडा, प्लास्टर ऑफ पेरिस"),
            ChapterItem("10-chem-3", "Metals & Non-Metals", "धातु एवं अधातु", "Reactivity series, ionic bonding, extraction, corrosion", "सक्रियता श्रेणी, आयनिक आबंध, धातु निष्कर्षण"),
            ChapterItem("10-chem-4", "Carbon & Its Compounds", "कार्बन एवं उसके यौगिक", "Covalent bonding, homologous series, IUPAC naming, ethanol", "सहसंयोजी आबंध, समजातीय श्रेणी, IUPAC नामकरण")
        ),
        StudySubject.MATHEMATICS to listOf(
            ChapterItem("10-math-1", "Quadratic Equations", "द्विघात समीकरण", "Factorization, quadratic formula, discriminant & nature of roots", "गुणनखंड, द्विघाती सूत्र, विविक्तकर एवं मूलों की प्रकृति"),
            ChapterItem("10-math-2", "Arithmetic Progressions (AP)", "समांतर श्रेढ़ियाँ (AP)", "nth term formula, sum of n terms, word problems", "nवाँ पद, n पदों का योग, दैनिक जीवन प्रश्न"),
            ChapterItem("10-math-3", "Triangles & Coordinate Geometry", "त्रिभुज एवं निर्देशांक ज्यामिति", "Thales theorem (BPT), similarity, distance & section formula", "थेल्स प्रमेय, समरूपता, दूरी सूत्र एवं विभाजन सूत्र"),
            ChapterItem("10-math-4", "Trigonometry & Surface Areas", "त्रिकोणमिति एवं पृष्ठीय क्षेत्रफल", "Trig identities, heights & distances, cone, cylinder, sphere", "त्रिकोणमितीय सर्वसमिकाएँ, ऊँचाई और दूरी")
        )
    )

    private val class11 = mapOf(
        StudySubject.PHYSICS to listOf(
            ChapterItem("11-phy-1", "Kinematics & Laws of Motion", "गतिकी एवं गति के नियम", "Projectile motion, Newton's laws, friction, circular banking", "प्रक्षेप्य गति, न्यूटन के नियम, घर्षण, वृत्तीय गति"),
            ChapterItem("11-phy-2", "Work, Energy, Power & Rotational Motion", "कार्य, ऊर्जा, शक्ति एवं घूर्णन गति", "Work-energy theorem, moment of inertia, torque, angular momentum", "कार्य-ऊर्जा प्रमेय, जड़त्व आघूर्ण, बल आघूर्ण"),
            ChapterItem("11-phy-3", "Gravitation & Properties of Matter", "गुरुत्वाकर्षण एवं द्रव्य के गुण", "Kepler's laws, escape velocity, Bernoulli's theorem, viscosity", "केप्लर के नियम, पलायन वेग, बर्नौली प्रमेय"),
            ChapterItem("11-phy-4", "Thermodynamics, Oscillations & Waves", "ऊष्मागतिकी, दोलन एवं तरंगें", "First & second law, Carnot engine, SHM, Doppler effect", "ऊष्मागतिकी नियम, कार्नो इंजन, सरल आवर्त गति")
        ),
        StudySubject.CHEMISTRY to listOf(
            ChapterItem("11-chem-1", "Atomic Structure & Periodic Classification", "परमाणु संरचना एवं आवर्त वर्गीकरण", "Bohr model, quantum numbers, electronic configuration", "बोर मॉडल, क्वांटम संख्याएँ, इलेक्ट्रॉनिक विन्यास"),
            ChapterItem("11-chem-2", "Chemical Bonding & Molecular Structure", "रासायनिक आबंधन एवं आणविक संरचना", "VSEPR theory, hybridization, MOT, hydrogen bonding", "VSEPR सिद्धांत, संकरण, आणविक कक्षक सिद्धांत"),
            ChapterItem("11-chem-3", "Thermodynamics & Chemical Equilibrium", "ऊष्मागतिकी एवं रासायनिक साम्य", "Enthalpy, Gibbs free energy, Le Chatelier's principle, pH", "एन्थैल्पी, गिब्स ऊर्जा, ले शातेलिए नियम"),
            ChapterItem("11-chem-4", "Organic Chemistry: GOC & Hydrocarbons", "कार्बनिक रसायन: GOC एवं हाइड्रोकार्बन", "IUPAC nomenclature, inductive & resonance effects, benzene", "IUPAC नामकरण, प्रेरणिक व अनुनाद प्रभाव")
        ),
        StudySubject.MATHEMATICS to listOf(
            ChapterItem("11-math-1", "Sets, Relations, Functions & Complex Numbers", "समुच्चय, संबंध, फलन एवं सम्मिश्र संख्याएँ", "Domain & range, Argand plane, modulus, quadratic roots", "प्रांत और परिसर, आर्गंड तल, मापांक"),
            ChapterItem("11-math-2", "Trigonometric Functions & Straight Lines", "त्रिकोणमितीय फलन एवं सरल रेखाएँ", "Compound angle formulas, slope, distance from point to line", "त्रिकोणमितीय सूत्र, रेखा की ढाल"),
            ChapterItem("11-math-3", "Permutations, Binomial Theorem & Conic Sections", "क्रमचय-संचय, द्विपद प्रमेय एवं शंकु परिच्छेद", "nPr & nCr, circle, parabola, ellipse, hyperbola", "क्रमचय-संचय, वृत्त, परवलय, दीर्घवृत्त"),
            ChapterItem("11-math-4", "Limits, Derivatives & Probability", "सीमा, अवकलज एवं प्रायिकता", "Standard limits, first principle derivative, product & quotient rules", "मानक सीमाएँ, प्रथम सिद्धांत से अवकलज")
        )
    )

    private val class12 = mapOf(
        StudySubject.PHYSICS to listOf(
            ChapterItem("12-phy-1", "Electrostatics & Current Electricity", "स्थिरवैद्युतिकी एवं विद्युत धारा", "Coulomb's law, Gauss's law, capacitors, Kirchhoff's laws", "कूलॉम नियम, गॉस प्रमेय, संधारित्र, किरचॉफ के नियम"),
            ChapterItem("12-phy-2", "Magnetism, EMI & Alternating Current", "चुंबकत्व, विद्युत चुंबकीय प्रेरण एवं AC", "Biot-Savart law, Faraday's law, LCR circuit, transformers", "बायो-सावर्ट नियम, फैराडे नियम, LCR परिपथ"),
            ChapterItem("12-phy-3", "Ray Optics & Wave Optics", "किरण प्रकाशिकी एवं तरंग प्रकाशिकी", "Lens maker's formula, TIR, Huygens principle, YDSE", "लेंस मेकर सूत्र, पूर्ण आंतरिक परावर्तन, यंग प्रयोग"),
            ChapterItem("12-phy-4", "Dual Nature, Atoms, Nuclei & Semiconductors", "द्वैत प्रकृति, परमाणु, नाभिक एवं अर्धचालक", "Photoelectric effect, Bohr spectrum, p-n junction diode", "प्रकाश विद्युत प्रभाव, बोर स्पेक्ट्रम, p-n संधि डायोड")
        ),
        StudySubject.CHEMISTRY to listOf(
            ChapterItem("12-chem-1", "Solutions & Electrochemistry", "विलयन एवं वैद्युत रसायन", "Raoult's law, colligative properties, Nernst equation", "राउल्ट का नियम, अणुसंख्य गुणधर्म, नर्नस्ट समीकरण"),
            ChapterItem("12-chem-2", "Chemical Kinetics & Coordination Compounds", "रासायनिक बलगतिकी एवं उपसहसंयोजन यौगिक", "First-order rate law, Arrhenius equation, CFT, IUPAC naming", "प्रथम कोटि अभिक्रिया, आरहेनियस समीकरण"),
            ChapterItem("12-chem-3", "Haloalkanes, Alcohols, Phenols & Ethers", "हैलोऐल्केन, ऐल्कोहॉल, फ़ीनॉल एवं ईथर", "SN1 vs SN2 mechanisms, Lucas test, Reimer-Tiemann", "SN1 व SN2 अभिक्रिया, ल्यूकास परीक्षण"),
            ChapterItem("12-chem-4", "Aldehydes, Ketones, Carboxylic Acids & Amines", "ऐल्डिहाइड, कीटोन, कार्बोक्सिलिक अम्ल एवं ऐमीन", "Aldol condensation, Cannizzaro, Tollens test", "ऐल्डोल संघनन, कैनिज़ारो अभिक्रिया")
        ),
        StudySubject.MATHEMATICS to listOf(
            ChapterItem("12-math-1", "Matrices & Determinants", "आव्यूह एवं सारणिक", "Inverse of matrix, adjoint, solving linear equations", "आव्यूह का व्युत्क्रम, सहखंडज, रैखिक समीकरण हल"),
            ChapterItem("12-math-2", "Continuity, Differentiability & Applications", "सांतत्य, अवकलनीयता एवं अनुप्रयोग", "Chain rule, maxima & minima, rate of change", "श्रृंखला नियम, उच्चिष्ठ व निम्निष्ठ"),
            ChapterItem("12-math-3", "Integrals & Differential Equations", "समाकलन एवं अवकल समीकरण", "Integration by parts, definite integrals, area under curves", "खंडशः समाकलन, निश्चित समाकलन"),
            ChapterItem("12-math-4", "Vectors, 3D Geometry & Probability", "सदिश, त्रिविमीय ज्यामिति एवं प्रायिकता", "Dot & cross product, shortest distance, Bayes' theorem", "अदिश व सदिश गुणनफल, बेज़ प्रमेय")
        )
    )

    fun chaptersFor(level: ClassLevel, subject: StudySubject): List<ChapterItem> {
        val map = when (level) {
            ClassLevel.CLASS_10 -> class10
            ClassLevel.CLASS_11 -> class11
            ClassLevel.CLASS_12, ClassLevel.GENERAL -> class12
        }
        return map[subject].orEmpty()
    }

    fun starterPrompts(language: Language, level: ClassLevel): List<String> {
        return if (language == Language.HI) {
            when (level) {
                ClassLevel.CLASS_10 -> listOf(
                    "ओम का नियम (Ohm's Law) उदाहरण सहित समझाएं",
                    "द्विघात समीकरण 2x² - 7x + 3 = 0 के मूल ज्ञात करें",
                    "अम्ल, क्षार और pH स्केल के महत्वपूर्ण बिंदु बताएं",
                    "अवतल और उत्तल दर्पण के उपयोग व सूत्र लिखें"
                )
                ClassLevel.CLASS_11 -> listOf(
                    "प्रक्षेप्य गति (Projectile Motion) के सूत्र व्युत्पन्न करें",
                    "VSEPR सिद्धांत और संकरण (Hybridization) समझाएं",
                    "सीमा lim(x→0) sin(3x)/x का मान निकालें",
                    "ऊष्मागतिकी का प्रथम नियम और एन्थैल्पी समझाएं"
                )
                else -> listOf(
                    "गॉस का नियम (Gauss's Law) और इसके अनुप्रयोग समझाएं",
                    "SN1 और SN2 अभिक्रिया में मुख्य अंतर तालिका सहित बताएं",
                    "∫ x·eˣ dx का खंडशः समाकलन (Integration by Parts) करें",
                    "किरचॉफ के नियमों (KCL व KVL) से परिपथ कैसे हल करें?"
                )
            }
        } else {
            when (level) {
                ClassLevel.CLASS_10 -> listOf(
                    "Explain Ohm's Law with a solved Class 10 numerical",
                    "Find the roots of 2x² - 7x + 3 = 0 using the quadratic formula",
                    "Compare Acids, Bases, and pH scale with board exam tips",
                    "Derive mirror formula sign conventions for concave & convex mirrors"
                )
                ClassLevel.CLASS_11 -> listOf(
                    "Derive time of flight, max height, and range for Projectile Motion",
                    "Explain VSEPR theory and sp³, sp², sp hybridization with shapes",
                    "Evaluate lim(x→0) sin(3x)/x and explain standard limits",
                    "Explain Le Chatelier's Principle with Ammonia Haber process example"
                )
                else -> listOf(
                    "Explain Gauss's Law and electric field due to a charged shell",
                    "Compare SN1 and SN2 reaction mechanisms with stereochemistry",
                    "Solve ∫ x·eˣ dx step-by-step using integration by parts",
                    "State Nernst Equation and calculate EMF for a Daniell cell"
                )
            }
        }
    }
}
