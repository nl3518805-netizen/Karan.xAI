package com.karanxai.app.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun MarkdownText(
    markdown: String,
    modifier: Modifier = Modifier
) {
    val lines = markdown.replace("\r\n", "\n").split("\n")
    Column(
        modifier = modifier,
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        var i = 0
        while (i < lines.size) {
            val line = lines[i]
            val trimmed = line.trim()

            when {
                trimmed.startsWith("```") -> {
                    val codeLines = mutableListOf<String>()
                    i++
                    while (i < lines.size && !lines[i].trim().startsWith("```")) {
                        codeLines.add(lines[i])
                        i++
                    }
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(
                                color = MaterialTheme.colorScheme.surfaceVariant,
                                shape = RoundedCornerShape(10.dp)
                            )
                            .border(
                                width = 1.dp,
                                color = MaterialTheme.colorScheme.outline,
                                shape = RoundedCornerShape(10.dp)
                            )
                            .padding(12.dp)
                    ) {
                        Text(
                            text = codeLines.joinToString("\n"),
                            fontFamily = FontFamily.Monospace,
                            fontSize = 13.sp,
                            lineHeight = 19.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }
                trimmed.startsWith("$$") -> {
                    val formula = if (trimmed.endsWith("$$") && trimmed.length > 4) {
                        cleanLatexForMobile(trimmed.removePrefix("$$").removeSuffix("$$").trim())
                    } else {
                        val mathBuf = mutableListOf<String>()
                        val first = trimmed.removePrefix("$$").trim()
                        if (first.isNotEmpty()) mathBuf.add(first)
                        i++
                        while (i < lines.size && !lines[i].trim().endsWith("$$")) {
                            mathBuf.add(lines[i].trim())
                            i++
                        }
                        if (i < lines.size) {
                            val last = lines[i].trim().removeSuffix("$$").trim()
                            if (last.isNotEmpty()) mathBuf.add(last)
                        }
                        cleanLatexForMobile(mathBuf.joinToString(" "))
                    }
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(
                                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.65f),
                                shape = RoundedCornerShape(10.dp)
                            )
                            .border(
                                width = 1.dp,
                                color = MaterialTheme.colorScheme.outline,
                                shape = RoundedCornerShape(10.dp)
                            )
                            .padding(horizontal = 12.dp, vertical = 10.dp)
                    ) {
                        Text(
                            text = formula,
                            fontFamily = FontFamily.Monospace,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Medium,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }
                trimmed.startsWith("### ") -> {
                    Text(
                        text = formatInlineMarkdown(trimmed.removePrefix("### ")),
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onSurface,
                        modifier = Modifier.padding(top = 6.dp)
                    )
                }
                trimmed.startsWith("## ") -> {
                    Text(
                        text = formatInlineMarkdown(trimmed.removePrefix("## ")),
                        style = MaterialTheme.typography.titleLarge.copy(fontSize = 17.sp),
                        color = MaterialTheme.colorScheme.onSurface,
                        modifier = Modifier.padding(top = 8.dp)
                    )
                }
                trimmed.startsWith("# ") -> {
                    Text(
                        text = formatInlineMarkdown(trimmed.removePrefix("# ")),
                        style = MaterialTheme.typography.titleLarge,
                        color = MaterialTheme.colorScheme.onSurface,
                        modifier = Modifier.padding(top = 8.dp)
                    )
                }
                trimmed.startsWith("- ") || trimmed.startsWith("* ") -> {
                    Row(
                        modifier = Modifier.padding(start = 6.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            text = "•",
                            style = MaterialTheme.typography.bodyLarge,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Text(
                            text = formatInlineMarkdown(trimmed.drop(2)),
                            style = MaterialTheme.typography.bodyLarge,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }
                trimmed.isNotEmpty() -> {
                    Text(
                        text = formatInlineMarkdown(trimmed),
                        style = MaterialTheme.typography.bodyLarge,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
            }
            i++
        }
    }
}

private fun cleanLatexForMobile(raw: String): String {
    return raw
        .replace("\\frac", "")
        .replace("\\times", "×")
        .replace("\\cdot", "·")
        .replace("\\pm", "±")
        .replace("\\sqrt", "√")
        .replace("\\int", "∫")
        .replace("\\sum", "∑")
        .replace("\\infty", "∞")
        .replace("\\alpha", "α")
        .replace("\\beta", "β")
        .replace("\\gamma", "γ")
        .replace("\\theta", "θ")
        .replace("\\lambda", "λ")
        .replace("\\mu", "μ")
        .replace("\\pi", "π")
        .replace("\\omega", "ω")
        .replace("\\Delta", "Δ")
        .replace("\\rightarrow", "→")
        .replace("\\rightleftharpoons", "⇌")
        .replace("\\le", "≤")
        .replace("\\ge", "≥")
        .replace("\\neq", "≠")
        .replace("\\approx", "≈")
        .replace("\\,", " ")
        .replace("{", "(")
        .replace("}", ")")
}

@Composable
private fun formatInlineMarkdown(text: String): AnnotatedString {
    val cleaned = text.replace("$", "")
    val boldColor = MaterialTheme.colorScheme.onSurface
    val codeBg = MaterialTheme.colorScheme.surfaceVariant
    val codeFg = MaterialTheme.colorScheme.primary

    return buildAnnotatedString {
        var idx = 0
        while (idx < cleaned.length) {
            when {
                cleaned.startsWith("**", idx) -> {
                    val end = cleaned.indexOf("**", idx + 2)
                    if (end != -1) {
                        withStyle(SpanStyle(fontWeight = FontWeight.Bold, color = boldColor)) {
                            append(cleanLatexForMobile(cleaned.substring(idx + 2, end)))
                        }
                        idx = end + 2
                    } else {
                        append(cleaned[idx])
                        idx++
                    }
                }
                cleaned[idx] == '`' -> {
                    val end = cleaned.indexOf('`', idx + 1)
                    if (end != -1) {
                        withStyle(
                            SpanStyle(
                                fontFamily = FontFamily.Monospace,
                                background = codeBg,
                                color = codeFg,
                                fontSize = 13.sp
                            )
                        ) {
                            append(" ${cleaned.substring(idx + 1, end)} ")
                        }
                        idx = end + 1
                    } else {
                        append(cleaned[idx])
                        idx++
                    }
                }
                else -> {
                    val nextSpecial = listOf(
                        cleaned.indexOf("**", idx),
                        cleaned.indexOf('`', idx)
                    ).filter { it >= 0 }.minOrNull() ?: cleaned.length
                    append(cleanLatexForMobile(cleaned.substring(idx, nextSpecial)))
                    idx = nextSpecial
                }
            }
        }
    }
}
