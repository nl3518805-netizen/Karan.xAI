# Karan.xAI — Mobile-Only Free Android APK Build Guide

This package contains the complete native **Kotlin + Jetpack Compose (Material 3)** Android source code, Gradle build scripts, Android manifest, resources, and automated CI APK builder for **Karan.xAI**.

You can compile this into an installable `.apk` file **using only your Android phone and 100% free tools**—no PC or paid subscription required.

---

## Method 1 (Recommended): Free Cloud APK Build via Mobile Browser (GitHub Actions)

1. **Download & Extract**: Download `KaranXAI-Android.zip` from Karan.xAI onto your phone and extract it using your phone's Files app (or ZArchiver, free).
2. **Create a Free GitHub Repository**: Open [github.com](https://github.com) in Chrome on your phone, sign in to a free account, and create a new repository (e.g., `karan-xai-android`).
3. **Upload Files**: Tap **uploading an existing file** on GitHub (or use a free mobile Git app like **MGit** / **Termux** `git push`) to upload the extracted project folders (`app/`, `gradle/`, `.github/`, `build.gradle.kts`, `settings.gradle.kts`, `gradle.properties`, `README_ANDROID.md`).
4. **Build the APK**: Open the **Actions** tab in your GitHub repo on your phone, tap **Build Karan.xAI Android APK**, and tap **Run workflow**.
5. **Download & Install**: After ~2–3 minutes, scroll down to **Artifacts** on the completed run, tap **KaranXAI-Debug-APK**, unzip the downloaded file, and tap `app-debug.apk` to install on your phone.

---

## Method 2: On-Device APK Build with AndroidIDE (Free Android App)

1. Install **AndroidIDE** (free, open-source IDE for Android) from GitHub Releases or F-Droid.
2. Extract `KaranXAI-Android.zip` to `/storage/emulated/0/Projects/KaranXAI`.
3. Open **AndroidIDE**, select **Open Project**, and choose the `KaranXAI` folder.
4. Wait for Gradle sync to finish, then tap **Run / Build APK** to compile and install directly on your phone.

---

## Method 3: On-Device Command-Line Build with Termux (Free)

1. Install **Termux** (from F-Droid) and **ZArchiver** on your Android phone.
2. Extract `KaranXAI-Android.zip` into `~/KaranXAI`.
3. In Termux, install JDK 17 and Gradle:
   ```bash
   pkg update && pkg upgrade -y
   pkg install openjdk-17 gradle wget unzip -y
   ```
4. Configure Android command-line tools (`sdkmanager "platforms;android-35" "build-tools;35.0.0"`) and set `ANDROID_HOME`.
5. Run inside `~/KaranXAI`:
   ```bash
   gradle assembleDebug --no-daemon
   ```
   Your APK will be created at `app/build/outputs/apk/debug/app-debug.apk`.

---

## Optional: Custom Backend URL

By default, the Android app connects to the Karan.xAI server backend (`gemini-4-hydrogen`). To point to your own server URL during build time, create `local.properties` in the project root:

```properties
KARANXAI_API_URL=https://your-server-url.example.com
```
